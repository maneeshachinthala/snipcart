import { NextApiRequest, NextApiResponse } from "next";
import { products } from "../..";

export default function  handler(req: NextApiRequest, res: NextApiResponse) {
    res.status(200).json(products);
}